package com.ds.pojo;

public class SongRecommendation {

	private double score;
	private long totalCountOfSong;
	private int ds_song_id;
	private String msd_song_id;

	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public long getTotalCountOfSong() {
		return totalCountOfSong;
	}
	public void setTotalCountOfSong(long totalCountOfSong) {
		this.totalCountOfSong = totalCountOfSong;
	}
	public int getDs_song_id() {
		return ds_song_id;
	}
	public void setDs_song_id(int ds_song_id) {
		this.ds_song_id = ds_song_id;
	}
	public String getMsd_song_id() {
		return msd_song_id;
	}
	public void setMsd_song_id(String msd_song_id) {
		this.msd_song_id = msd_song_id;
	}

	
	
	
	
}
